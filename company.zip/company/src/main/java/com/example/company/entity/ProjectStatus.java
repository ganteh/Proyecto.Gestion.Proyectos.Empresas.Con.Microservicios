package com.example.company.entity;


public enum ProjectStatus {
    RECEIVED,
    REJECTED,
    IN_EXECUTION,
    CLOSED
}

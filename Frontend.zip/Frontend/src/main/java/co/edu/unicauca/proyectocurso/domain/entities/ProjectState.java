
package co.edu.unicauca.proyectocurso.domain.entities;

/**
 *
 * @author ibell
 */
public enum ProjectState {
    RECEIVED,
    ACCEPTED,
    REJECTED,
    IN_EXECUTION,
    CLOSED
}